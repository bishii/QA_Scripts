import tkinter as tk
import xattr
import glob, os
import readchar
import getch
from PIL import Image, ImageTk  # Place this at the end (to avoid any conflicts/errors)

size = 500,500

window = tk.Tk()
img = None
#window.geometry("50x50") # (optional)    
lbl = tk.Label(window, width=500, height=500, image=img)
T = tk.Text(window, height=2, width=80)

keyMap = {'a':'Food', 's':'Scenic', 'd':'Family', 'f':'Temple-Shrine'}

images = glob.glob("IMG_*.JPG")

totalCount = len(images)

count = 1
for imagefile in images:
	i = Image.open(imagefile)
	ii = i.thumbnail(size)
	img = ImageTk.PhotoImage(i)
	lbl.configure(image=img)
	lbl.image = img
	lbl.pack()
	T.delete("1.0", tk.END)
	T.insert(tk.END, "FILE: %s (%s of %s)\nTAG WITH: a)Food  s)Scenic  d)Family   f)Temples\n" % (imagefile, count, totalCount))
	T.pack()

	count += 1 
	#currentTags = xattr.getxattr(imagefile,'com.apple.metadata:_kMDItemUserTags')
	#print(currentTags)
	print("Current file: %s" % imagefile)
	#print("TAG WITH: A)Food  S)Scenic  D)Family   F)Temples")
	ans=input("TAG WITH: a)Food  s)Scenic  d)Family   f)Temples -->")
	#ans = readchar.readkey()
	#ans = getch.getch()
	#ans=input('L')
	x = '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0">\
			<array><string>%s</string></array></plist>' % keyMap[ans]
	b = bytes (x, 'utf-8')
	xattr.setxattr(imagefile,'com.apple.metadata:_kMDItemUserTags', b)
	print("Added Tag: **%s** to %s" %(keyMap[ans], imagefile))

input("All Finished2!")
window.destroy()

window.mainloop()
