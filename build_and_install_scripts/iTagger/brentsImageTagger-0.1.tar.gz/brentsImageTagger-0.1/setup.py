from setuptools import setup

setup(name='brentsImageTagger',
      version='0.1',
      description='Local Image Tagger',
      url='http://github.com/storborg/funniest',
      author='Brent Ishii',
      author_email='brent@brent.com',
      license='MIT',
      packages=['itagger'],
      install_requires=['xattr','readchar','pillow'],
      zip_safe=False)
